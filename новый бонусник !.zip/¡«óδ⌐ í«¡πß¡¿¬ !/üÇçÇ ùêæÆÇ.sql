-- phpMyAdmin SQL Dump
-- version 4.4.15.10
-- https://www.phpmyadmin.net
--
-- Хост: localhost
-- Время создания: Апр 08 2019 г., 10:25
-- Версия сервера: 5.7.23-24
-- Версия PHP: 5.3.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `u0608973_usd`
--

-- --------------------------------------------------------

--
-- Структура таблицы `bonus`
--

CREATE TABLE IF NOT EXISTS `bonus` (
  `id` int(1) NOT NULL,
  `uid` int(11) NOT NULL,
  `login` varchar(40) NOT NULL,
  `sum` decimal(10,2) NOT NULL,
  `date` varchar(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=cp1251 PACK_KEYS=0;

-- --------------------------------------------------------

--
-- Структура таблицы `online`
--

CREATE TABLE IF NOT EXISTS `online` (
  `id` int(11) NOT NULL,
  `ip` varchar(30) NOT NULL,
  `last_time` int(11) NOT NULL,
  `login` varchar(60) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;

-- --------------------------------------------------------

--
-- Структура таблицы `rich_kassa`
--

CREATE TABLE IF NOT EXISTS `rich_kassa` (
  `id` int(11) NOT NULL,
  `wallet` varchar(11) NOT NULL,
  `sum` decimal(10,2) NOT NULL,
  `ord` int(11) NOT NULL,
  `ref_id` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `date` int(11) NOT NULL,
  `date_word` varchar(20) NOT NULL,
  `date2` int(11) NOT NULL,
  `date2_word` varchar(20) NOT NULL,
  `power` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `rich_payments`
--

CREATE TABLE IF NOT EXISTS `rich_payments` (
  `id` int(11) NOT NULL,
  `wallet` varchar(11) NOT NULL,
  `sum` decimal(10,2) NOT NULL,
  `date` int(22) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `rich_stats`
--

CREATE TABLE IF NOT EXISTS `rich_stats` (
  `id` int(11) NOT NULL,
  `users` int(11) NOT NULL,
  `users_today` int(11) NOT NULL,
  `payments` decimal(10,2) NOT NULL,
  `powers` decimal(10,2) NOT NULL,
  `payout` decimal(10,2) NOT NULL,
  `day` int(11) NOT NULL,
  `ups` decimal(10,2) NOT NULL,
  `online_dt` int(11) NOT NULL,
  `games_ms` int(11) NOT NULL,
  `ms_kassa` decimal(10,4) NOT NULL,
  `admin_ms_s_1` decimal(10,4) NOT NULL,
  `admin_ms_s_2` decimal(10,4) NOT NULL,
  `ref_sum` decimal(10,4) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `rich_stats`
--

INSERT INTO `rich_stats` (`id`, `users`, `users_today`, `payments`, `powers`, `payout`, `day`, `ups`, `online_dt`, `games_ms`, `ms_kassa`, `admin_ms_s_1`, `admin_ms_s_2`, `ref_sum`) VALUES
(1, 0, 0, 0.00, 0.00, 0.00, 0, 0.00, 0, 0, 0.0000, 0.0000, 0.0000, 0.0000);

-- --------------------------------------------------------

--
-- Структура таблицы `rich_wallets`
--

CREATE TABLE IF NOT EXISTS `rich_wallets` (
  `id` int(11) NOT NULL,
  `wallet` varchar(11) NOT NULL,
  `balance` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `power` decimal(10,5) NOT NULL,
  `dep` decimal(10,2) NOT NULL DEFAULT '0.00',
  `vvel` decimal(10,2) NOT NULL DEFAULT '0.00',
  `vivel` decimal(10,2) NOT NULL DEFAULT '0.00',
  `ip` varchar(44) NOT NULL,
  `sbor` int(44) NOT NULL,
  `prines` decimal(10,2) NOT NULL DEFAULT '0.00',
  `poluchil` decimal(10,2) NOT NULL DEFAULT '0.00',
  `col_ref` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `ref_id` int(11) NOT NULL DEFAULT '0',
  `ref_sum` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `refs` int(11) NOT NULL DEFAULT '0',
  `bonus_gif_d` int(11) NOT NULL,
  `bets_mssum` decimal(10,2) NOT NULL,
  `bets_wmssum` decimal(10,4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `room_ms`
--

CREATE TABLE IF NOT EXISTS `room_ms` (
  `id` int(11) unsigned NOT NULL,
  `date` int(11) NOT NULL,
  `date_word` varchar(20) NOT NULL,
  `uid` int(11) NOT NULL,
  `login` varchar(40) NOT NULL,
  `digits` int(11) NOT NULL,
  `target` varchar(20) NOT NULL,
  `sum` decimal(10,2) NOT NULL,
  `chance` decimal(10,2) NOT NULL,
  `profit` decimal(10,4) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `bonus`
--
ALTER TABLE `bonus`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `online`
--
ALTER TABLE `online`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `rich_kassa`
--
ALTER TABLE `rich_kassa`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `rich_payments`
--
ALTER TABLE `rich_payments`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `rich_stats`
--
ALTER TABLE `rich_stats`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `rich_wallets`
--
ALTER TABLE `rich_wallets`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `room_ms`
--
ALTER TABLE `room_ms`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `bonus`
--
ALTER TABLE `bonus`
  MODIFY `id` int(1) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `online`
--
ALTER TABLE `online`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `rich_kassa`
--
ALTER TABLE `rich_kassa`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `rich_payments`
--
ALTER TABLE `rich_payments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `rich_stats`
--
ALTER TABLE `rich_stats`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT для таблицы `rich_wallets`
--
ALTER TABLE `rich_wallets`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `room_ms`
--
ALTER TABLE `room_ms`
  MODIFY `id` int(11) unsigned NOT NULL AUTO_INCREMENT;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
