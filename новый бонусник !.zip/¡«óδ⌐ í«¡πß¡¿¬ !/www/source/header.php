<table width="100%" height="43" border="0">
<tbody>
<tr align="center" height="80%" bgcolor="#00B5D4" style="font-size:20px;color:#ffffff;text-shadow:#203644 1px 1px 1px;">
<td width="25%" height="28" style="box-shadow: inset 0px 0px 2px rgba(0,0,0,0.9);height:54px;">Пользователей:<br><?=$st["users"] ;?> чел.</td>
<td width="25%" style="box-shadow:inset 0px 0px 2px rgba(0,0,0,0.9);">Новых:<br><?=$st["users_today"];?></b>  чел.</td>
<td width="25%" style="box-shadow:inset 0px 0px 2px rgba(0,0,0,0.9);">Резерв:<br><?=($st["ups"]-$st["payout"]);?></b> Руб.</td>
<td width="25%" style="box-shadow:inset 0px 0px 2px rgba(0,0,0,0.9);">Онлайн:<br><?=$online_c;?></b> чел.</td>
<?php
//echo '<td width="25%" style="box-shadow:inset 0px 0px 2px rgba(0,0,0,0.9);">Выплачено:<br>'.$st["payout"].' Руб.</td>';
?>
</tr>
</table>
