<?
# ��������� ��������
include("inc/config.php");

/*
$sign_hash=5;
$_POST['m_sign']=$sign_hash;
$_POST['m_status']='success';
$_POST['m_operation_id']=567;
$_POST['m_amount']=200;
$_POST['m_orderid']=89;
*/


if (isset($_POST['m_operation_id']) && isset($_POST['m_sign']))
{
	$m_key = $shopKEY;
	$arHash = array($_POST['m_operation_id'],
			$_POST['m_operation_ps'],
			$_POST['m_operation_date'],
			$_POST['m_operation_pay_date'],
			$_POST['m_shop'],
			$_POST['m_orderid'],
			$_POST['m_amount'],
			$_POST['m_curr'],
			$_POST['m_desc'],
			$_POST['m_status'],
			$m_key);
	$sign_hash = strtoupper(hash('sha256', implode(':', $arHash)));
	if ($_POST['m_sign'] == $sign_hash && $_POST['m_status'] == 'success')
	{
	

	$m_amount = $_POST['m_amount'];
	$m_orderid = $_POST['m_orderid'];

	$sql = $mysqli->query("SELECT * FROM rich_kassa WHERE ord = '{$m_orderid}'");
	$inf = $sql->fetch_array();


    if(empty($inf['id'])){ echo $_POST['m_orderid'].'|error'; exit; }
    if(empty($inf['power'])){ echo $_POST['m_orderid'].'|error'; exit; }
    if($inf['status']==1){ echo $_POST['m_orderid'].'|success'; exit; }
	

	$sql = $mysqli->query("UPDATE rich_kassa SET status = '1' WHERE ord = '{$m_orderid}'");


    $powered = $inf[power];
    	
    # �������
    $refus1 = $inf['sum']*0.10;


    if($inf[ref_id]>0){
    $sql = $mysqli->query("UPDATE rich_wallets SET balance = balance + '$refus1', ref_sum = ref_sum+'$refus1' WHERE id = '".$inf[ref_id]."' LIMIT 1");
    }
	else{
	$refus1=0;
	}
	
	// ����������
	$sql = $mysqli->query("UPDATE rich_wallets SET power = power + '$powered', col_ref = col_ref + '$refus1', vvel = vvel+'".$inf[sum]."' WHERE wallet = '{$inf[wallet]}'");
	
	# ��������� �����
    $sql=$mysqli->query("UPDATE rich_stats SET powers = powers + '{$powered}',ups=ups+'{$inf[sum]}' WHERE id = '1' LIMIT 1");
	
		echo $_POST['m_orderid'].'|success';
		exit;
	}
	echo $_POST['m_orderid'].'|error';
}
?>
