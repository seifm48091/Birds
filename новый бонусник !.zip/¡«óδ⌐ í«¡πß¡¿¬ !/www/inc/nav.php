<?
if(isset($_GET["nav"])){
$nav = protect($_GET['nav']);
switch($nav) {
		case "about": include("pages/about.php"); break;
		case "my": include("pages/my.php"); break;
		case "ms": include("pages/ms.php"); break;
		case "bonus": include("pages/bonus.php"); break;
		case "faq": include("pages/faq.php"); break;
		case "contact": include("pages/contact.php"); break;
		case "payments": include("pages/payments.php"); break;
		case "home": include("pages/home.php"); break;
        case "partners": include("pages/partners.php"); break;

		# ����� ***** ����������� ������
		case "exit": 
			unset($_SESSION['wallet']);
			session_unset();
			session_destroy();
			header("Location: ./");
			break;
			
		# �������� ������
	    default: @include("pages/404.php"); break;
		}	
}else @include("pages/home.php");
?>
