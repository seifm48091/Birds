<?php
$mysqli = new mysqli('localhost','user','pass','user');



if ($mysqli->connect_error) {
    die('Error : ('. $mysqli->connect_errno .') '. $mysqli->connect_error);
}

# PAYEER setiings
# Пополнение
$shopID = "88567576";
$shopKEY = "fjkfdj777";

# Вывод
$Account = 'P000000';
$apiID = '777777777';
$apiKEY = '777777777777';

$minPay = 1;

$NameSite="site.ru";
$adminmail = "admin@mail.ru";
$set_time = time();

// ================  CONFIG  ==================
//$sql=$mysqli->query("SELECT * FROM rich_config WHERE id ='1' LIMIT 1");
//$cfg=$sql->fetch_array();

// ================  STATS  ===================
$sql=$mysqli->query("SELECT * FROM rich_stats WHERE id ='1' LIMIT 1");
$st=$sql->fetch_array();
?>
